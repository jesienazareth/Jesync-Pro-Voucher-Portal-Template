// 0 = single vendo, and set the first "vendoIp"
// 1 = traditional (client choose a vendo), 
// 2 = interface name ( this will preserve one hotspot server ip only)
// var VendoOption = 0;
var VendoOption = 0;

//list here all node mcu address for multi vendo setup
var multiVendoAddresses = [
	{
		vendoName: "GCASH CONNECT", //change accordingly to your vendo name
		vendoIp: "100.65.0.10", //change accordingly to your vendo ip
		interfaceName: "HS-GCashConnect", // hotspot interface name preser
	},
	{
		vendoName: "Gcash3021", //change accordingly to your vendo name
		vendoIp: "100.88.1.10", //change accordingly to your vendo ip
		interfaceName: "Gcash3021", // hotspot interface name preser
	}

];

//0 means its login by username only, 1 = means if login by username + password
var loginOption = 0; //replace 1 if you want login voucher by username + password

var showPauseTime = true;

// Telegram Feature
var EnableTelegram = false;

// Notify for every coin inserted by custmer via Telegram.
var CoinDropNotify = false;

// Telegram Token
var  telegramToken  = "";

// Telegram ChatID
var  telechatId = "";

// If voucher starts with these letters then "Extend time" and "Pause time" will be removed
var noExpause = ['ME', 'Vc', 'MO', 'Ec'];
var Subscription = true; 
// if noExpause set above, replace true if you want to replace remaining time into "SUBSCRIPTION"

var bannerText = "Paki OFF ang WiFi para Automatic Pause!!!";

var Footer = '';