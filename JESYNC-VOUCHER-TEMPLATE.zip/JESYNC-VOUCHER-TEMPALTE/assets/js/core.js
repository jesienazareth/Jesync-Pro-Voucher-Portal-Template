var _0x3511a3 = _0xd8f8;
! function() {
    for (var e = _0xd8f8, t = _0x1ec6();;) try {
        if (731521 == +parseInt(e(247)) * (parseInt(e(238)) / 2) + -parseInt(e(235)) / 3 * (parseInt(e(232)) / 4) + -parseInt(e(347)) / 5 * (parseInt(e(409)) / 6) + -parseInt(e(291)) / 7 + parseInt(e(373)) / 8 + parseInt(e(266)) / 9 * (-parseInt(e(412)) / 10) + parseInt(e(383)) / 11 * (parseInt(e(268)) / 12)) break;
        t.push(t.shift())
    } catch (e) {
        t.push(t.shift())
    }
}();
var errorCodeMap = [];

function _0xd8f8(e, t) {
    var n = _0x1ec6();
    return (_0xd8f8 = function(e, t) {
        return n[e -= 206]
    })(e, t)
}
errorCodeMap[_0x3511a3(403)] = _0x3511a3(310), errorCodeMap[_0x3511a3(302)] = _0x3511a3(216), errorCodeMap[_0x3511a3(394)] = _0x3511a3(343), errorCodeMap["no.internet.detected"] = _0x3511a3(256), errorCodeMap[_0x3511a3(421)] = _0x3511a3(357);
var totalCoinReceived = 0,
    insertcoinbg = new Audio(_0x3511a3(339));
insertcoinbg.loop = !0;
var coinCount = new Audio(_0x3511a3(254)),
    voucher = "",
    insertingCoin = !1,
    voucherToConvert = "",
    dev_ip = $(_0x3511a3(285))[_0x3511a3(298)](),
    flagTimer = _0x3511a3(307),
    isPaused = !1,
    uIp = $(_0x3511a3(361)).html(),
    mac = $("#device-mac")[_0x3511a3(298)](),
    sessiontime = $(_0x3511a3(211)).val(),
    interfaceName = $("#interfaceName")[_0x3511a3(385)](),
    nouptime = $(_0x3511a3(264))[_0x3511a3(385)](),
    vendorIpAddress = "";

function timeReached() {
    var e = _0x3511a3;
    toastr[e(248)](e(316), e(228), {
        positionClass: "toast-top-right",
        closeButton: !1,
        progressBar: !0,
        timeOut: e(257)
    }), $[e(252)]({
        type: "POST",
        url: "/logout",
        data: e(233),
        success: function(e) {
            setTimeout(function() {
                location[_0xd8f8(420)]()
            }, 1e3)
        }
    })
}

function pause() {
    var e, t, n = _0x3511a3;
    "pause" == flagTimer ? ($[n(252)]({
        type: n(219),
        url: n(215),
        data: n(233),
        success: function(e) {
            var t = n;
            $("#status")[t(298)](t(368)), $(t(206))[t(298)](t(342)), $(t(265))[t(321)]("paused"), $(t(265))[t(221)](t(359)), $(t(350))[t(242)](t(404))
        }
    }), isPaused = !0, flagTimer = n(353)) : (isPaused = !1, flagTimer = "pause", e = $(n(264)).val(), t = 1 == loginOption ? e : "", $[n(252)]({
        type: n(219),
        url: n(275),
        data: {
            username: e,
            password: t
        }
    }), $(n(296))[n(298)](n(329)), $("#timesign")[n(298)](n(410)), $(n(265))[n(321)](n(359)), $(n(350))[n(242)]("Pause Time"))
}

function _0x1ec6() {
    var e = ["activeVoucher", '" data-target="', '<span class="text paused"><i class="fa fa-pause blink pause-button"></i>  <span class="">Time Paused</span></span>', "modal", "Pause Time", "undefined", " peso was inserted", "2776504cWuoli", "#username", "option", "#exp", "%0A Vendo IP: ", "floor", "http://", "/topUp", "--------------------------------------------%0A Insert Coin %0A--------------------------------------------%0A MAC: ", "#vendoSelected", "55kaSxAG", "Done Paying", "val", "&mac=", "totalCoin", "#loaderDiv", "hr.", "https://api.telegram.org/bot", "</td>", "3500", '<button style="border-radius:5px;width:100%;" data-value="', "coin.slot.banned", "append", "data", " Days ", "Please enter voucher code to convert", "display: none!important", "width: ", "&text=", "waitTime", "coin.not.inserted", "Resume Time", "</b>hr.", "#remainTime", "Voucher Code Here", "&parse_mode=html", "150tlJDsx", "Remaining Time:", "#totalCoin", "20WPkrSm", "click", "voucher=", "&ipAddress=", "/cancelTopUp", "coin.is.reading", "Unlimited", " %0A--------------------------------------------", "reload", "product.hash.invalid", "newCoin", "currentTime", "#user", "#timesign", "selectedVendo", "Please enter voucher code!", "errorCode", "<tr>", "#sessiontime", "#done-paying", "removeItem", "play", "/logout", "Coin slot is busy", "#userpass", "disabled", "POST", "%0A Location: ", "removeClass", '<div class="inner-wrapper"><h2>Subscription</h2></div>', "#promoRateBtn", "activeMac", "Connecting", "setInterval", "#promoRatesModal", "Disconnecting!", '<img width="45" src="assets/img/disabled2.png" style="margin-top:-3px;"><span class="text-danger"> Disconnected</span>', "#vendoSelected option:selected", "%0A MAC: ", "2282188YDdPcv", "erase-cookie=true", "#ExP", "6KFtrbt", "is offline", "GET", "1388esVFxy", "#progress-msg", "&extendTime=0", "Coinslot was cancelled", "text", "voucher", "%0A--------------------------------------------", "getItem", "attr", "1354VeAmUu", "info", "/data/", "sec", "</b>min.", "ajax", "min.", "assets/coin-received.mp3", "removeAttr", "No internet connection as of the moment, Please try again later", "2000", "</button>", "min", "%0A IP: ", "success", ".txt", "#progressDiv", "#nouptime", "#rtime", "6480027qIowtm", "#voucherCode", "9608076aOsfGL", "prop", "remainTime", "<b>0</b>", "Voucher is not available as of the moment, Please try again later", "error!!!", "length", "/login", "#vendoselect", "log", "Days ", "indexOf", "<b>", "status", "Coin slot expired", "#bannertext", "/checkCoin", "#device-ip", "</b>d.", "#SelectVendo", "placeholder", "&convertVoucher=", " option", "4620756WyOInP", "Logout", "Voucher converted succesfully", "show", "/useVoucher", "#status", "/status", "html", "#device-mac", "activeMacV", "style", "coinslot.busy", "<div class='spinner hidden'></div>", "erase-cookie=false", "/sendmessage?chat_id=", '.selectbtn[data-target="', "pause", "css", "#totalData", "Coin not inserted", "split", "Invalid voucher code", "%0A Voucher: ", "0h:0m", '<div class="text-primary ptime"><h2>Unlimited</h2></div>', "Time Limit Reached", "vendoIp", "Please wait!", "open", "true", "addClass", "hide", "ready", "Invalid Voucher", "%0A Total Coin Receive: ", "#vouLoginBtn", ".00</td>", "&extendTime=1", '<span class="text-success"><i class="fa fa-wifi"></i>  Connected</span>', ".selectbtn", "error", "selected", "timeAdded", "No Pause Time", "--------------------------------------------%0A Connecting %0A--------------------------------------------%0A MAC: ", "setItem", '" class="m-1 btn selectbtn btn-primary">', "no-display", "assets/insertcoinbg.mp3", "hour", "each", "Click Resume Time Button To Continue Surfing", "You have been banned from using coin slot, due to multiple request for insert coin, please try again later!", "#insertCoinModal", "text/plain", " Day ", "263475xQxOOM", "hidden.bs.modal", "%0A Loaction: ", "#pauseTimeBtn", "%0A IP:", "/getRates", "resume", "toast-top-right", "replace", "vendoName", "Product hash has been tampered, your a hacker", "Day ", "text-primary", "startsWith", ".uIp", "</b>", "display", "#totalTime", "send"];
    return (_0x1ec6 = function() {
        return e
    })()
}

function getRemainTime(o) {
    var t = _0x3511a3,
        e = replaceAll(mac, ":"),
        n = getStorageValue(t(366)),
        r = $(t(424))[t(385)]();
    vc = null == n ? "" == r ? e : r : n, n = 1 == loginOption ? vc : "", $[t(252)]({
        type: t(237),
        url: t(275),
        data: {
            username: vc,
            password: n
        },
        success: function(e) {
            var n = t;
            return $.ajax({
                type: n(237),
                url: "/status",
                success: function(e) {
                    var t = n,
                        e = parseInt(e);
                    $(t(388))[t(298)](t(303)), 0 < e ? ($[t(252)]({
                        type: t(219),
                        url: t(215),
                        data: "erase-cookie=true"
                    }), getStorageValue("activeMac") != $(t(299))[t(298)]() && doResumefix(), $("#vouLoginBtn").click(function(e) {
                        voucherAction()
                    }), $(t(374))[t(269)]("disabled", !1), $(t(374))[t(246)](t(288), t(407)), $("#timesign").html(t(342)), $(t(296))[t(298)](t(368)), $(t(350))[t(242)](t(404)), $(t(350))[t(413)](function(e) {
                        doResumefix()
                    }), $(t(406))[t(298)](secondsToDhms(e))) : (1 == o ? ($(t(326)).click(function(e) {
                        doConnect()
                    }), $(t(374))[t(269)]("disabled", !1), $("#username")[t(246)](t(288), t(407)), removeStorageValue(t(366))) : getRemainTime(o + 1), $("#status").html(t(229)), $(t(350))[t(322)](), removeStorageValue(t(366)))
                }
            }), !1
        }
    })
}

function doResumefix() {
    var t = _0x3511a3,
        e = getStorageValue(t(366)),
        n = $(t(424))[t(385)]();
    return voucher = null == e ? "" == n ? replaceAll(mac, ":") : n : getStorageValue(t(366)), n = 1 == loginOption ? voucher : "", $[t(252)]({
        type: t(219),
        url: "/login",
        data: {
            username: voucher,
            password: n
        },
        success: function(e) {
            location[t(420)]()
        }
    }), !1
}

function doLogin() {
    var e, t = _0x3511a3,
        n = $(t(264))[t(385)]();
    return e = 1 == loginOption ? n : "", $.ajax({
        type: "POST",
        url: t(275),
        data: {
            username: n,
            password: e
        },
        success: function(e) {
            location[t(420)]()
        }
    }), !1
}

function doConnect() {
    var e, t = _0x3511a3,
        n = $("#username")[t(385)]();
    return e = 1 == loginOption ? n : "", "" != n ? $[t(252)]({
        type: "POST",
        url: t(275),
        data: {
            username: n,
            password: e
        },
        success: function(e) {
            getStatus()
        }
    }) : toastr[t(331)](t(208)), !1
}

function getStatus() {
    var n = _0x3511a3;
    $.ajax({
        type: n(237),
        url: n(297),
        success: function(e) {
            var t = n;
            0 < parseInt(e) ? (toastr[t(248)](t(318), t(225), {
                positionClass: "toast-top-right",
                closeButton: !1,
                progressBar: !0,
                timeOut: t(392)
            }), setTimeout(function() {
                location[t(420)]()
            }, 1e3)) : toastr[t(331)](t(324))
        }
    })
}

function forceLogin() {
    var t = _0x3511a3;
    $(t(344)).modal(t(322)), toastr[t(248)](t(318), t(225), {
        positionClass: t(354),
        closeButton: !1,
        progressBar: !0,
        timeOut: t(392)
    }), setTimeout(function() {
        var e = t;
        "0" == sessiontime ? newLogin() : $[e(252)]({
            type: e(219),
            url: e(215),
            data: e(304),
            success: function(e) {
                setTimeout(function() {
                    doLogin()
                }, 1e3)
            }
        })
    }, 1e3)
}

function fetchValidity(r) {
    var e, a, i = _0x3511a3;
    5 < r ? fallbackValidity() : (e = replaceAll(mac, ":"), a = getStorageValue("activeMacV"), dataText = null == a ? 12 == nouptime[i(274)] ? nouptime : e : a, $[i(252)]({
        type: i(237),
        url: i(249) + dataText + i(262),
        success: function(e) {
            var t = i;
            null == a && setStorageValue(t(300), replaceAll(mac, ":")), $(t(234))[t(294)]();
            var n = e[t(311)]("#"),
                o = n[0],
                n = n[1];
            $(t(424))[t(385)](o), $("#exp").html(n), "0" == sessiontime && ($(t(265))[t(321)]("paused"), $(t(296))[t(298)](t(368)), $(t(206))[t(298)]("CLICK RESUME TIME BUTTON TO CONTINUE SURFING"), $(t(350)).text(t(404)), $(t(350))[t(413)](function(e) {
                doResumefix()
            })), $("#userpass")[t(385)](o), $(t(376))[t(298)](n), 50 < e[t(274)] && setTimeout(function() {
                fetchValidity(r++)
            }, 1e3)
        },
        error: function(e) {
            removeStorageValue(i(300)), fallbackValidity()
        }
    }))
}

function fallbackValidity() {
    setTimeout(function() {
        var n = _0xd8f8;
        "0" == sessiontime && "" != $(n(264)).val() && ($("#vendoselect").attr(n(301), n(399)), $(n(350)).text(n(292)), $(n(350))[n(413)](function(e) {
            var t = n;
            $[t(252)]({
                type: "POST",
                url: t(215),
                data: t(233),
                success: function(e) {
                    location[t(420)]()
                }
            })
        }), $(n(267)).attr(n(301), n(399)), $(n(265))[n(298)](n(315)))
    }, 1e3)
}

function replaceAll(e, t) {
    for (var n = _0x3511a3, o = e; 0 < o[n(279)](t);) o = o[n(355)](t, "");
    return o
}
$(document).ready(function() {
    var n = _0x3511a3;
    fetchValidity(1), $("#cstfooter").html(Footer), $(n(283)).html(bannerText);
    replaceAll(mac, ":"), $(n(217))[n(385)]();
    var t = sessiontime;
    $(n(424)).val();
    if ("0" == t && $(n(388))[n(298)]("<div class='spinner text-success'><center><b>Device Checking! Please Wait.</b></center></div>"), $(n(344)).on(n(348), function() {
        var e = n;
        clearInterval(timer), timer = null, insertingCoin = !1, insertcoinbg[e(307)](), (insertcoinbg[e(423)] = 0) == totalCoinReceived && $[e(252)]({
            type: e(219),
            url: e(379) + vendorIpAddress + e(416),
            data: e(414) + voucher + e(386) + mac,
            success: function(e) {},
            error: function(e, t) {}
        })
    }), 0 == VendoOption) vendorIpAddress = multiVendoAddresses[0][n(317)], $(n(276))[n(413)](function(e) {
        insertAction()
    });
    else if (1 == VendoOption) {
        $("#vendoselect")[n(413)](function(e) {
            var t = n;
            $(t(287))[t(369)](t(294))
        });
        for (var e = 0; e < multiVendoAddresses[n(274)]; e++) $("#vendoSelected")[n(395)]($("<option>", {
            value: multiVendoAddresses[e][n(317)],
            text: multiVendoAddresses[e][n(356)]
        }));
        var o = getStorageValue(n(207));
        vendorIpAddress = null != o ? o : multiVendoAddresses[0][n(317)], $(n(382)).val(vendorIpAddress), $(n(382)).change(function() {
            var e = n;
            vendorIpAddress = $("#vendoSelected")[e(385)](), setStorageValue(e(207), vendorIpAddress), insertAction()
        })
    } else if (2 == VendoOption) {
        $("#vendoselect").click(function(e) {
            insertAction()
        });
        for (e = 0; e < multiVendoAddresses[n(274)]; e++) multiVendoAddresses[e].interfaceName == interfaceName && (vendorIpAddress = multiVendoAddresses[e][n(317)], vendorName = multiVendoAddresses[e][n(356)])
    }
    nouptime[n(360)](noExpause[0]) || nouptime[n(360)](noExpause[1]) || nouptime[n(360)](noExpause[2]) || nouptime[n(360)](noExpause[3]) && 12 != nouptime[n(274)] ? ($(n(267)).attr(n(301), n(399)), $("#vendoselect")[n(246)](n(301), "display: none!important"), $(n(350))[n(246)]("style", n(399)), $(n(265))[n(321)]("text-primary"), $(n(296)).html(n(329)), Subscription && $(n(406))[n(298)](n(222))) : ("0" != t && ($(n(326))[n(413)](function(e) {
        voucherAction()
    }), $(n(374))[n(269)](n(218), !1), $(n(374))[n(246)](n(288), n(407)), setStorageValue(n(366), nouptime), setStorageValue(n(224), $("#device-mac")[n(298)]()), $(n(350))[n(242)](n(370)), $("#pauseTimeBtn")[n(413)](function(e) {
        pause()
    }), $(n(265))[n(321)]("text-primary"), $("#status")[n(298)](n(329)), showPauseTime || $(n(350)).addClass(n(338)), $("#remainTime")[n(298)](secondsToDhms(t)), window[n(226)](function() {
        var e = n;
        isPaused || (t--, $(e(406))[e(298)](secondsToDhms(t))), t <= 0 && timeReached()
    }, 1e3)), $(n(276))[n(308)](n(363), ""), $("#pauseTimeBtn").css(n(363), ""))
}), "" == nouptime && getRemainTime(0);
var timer = null;

function setStorageValue(e, t) {
    null != localStorage && localStorage[_0x3511a3(336)](e, t)
}

function removeStorageValue(e) {
    null != localStorage && localStorage[_0x3511a3(213)](e)
}

function getStorageValue(e) {
    if (null != localStorage) return localStorage[_0x3511a3(245)](e)
}

function newLogin() {
    location[_0x3511a3(420)]()
}

function notifyCoinSlotError(e) {
    toastr[_0x3511a3(331)](errorCodeMap[e])
}

function insertAction() {
    return callTopupAPI(totalCoinReceived = 0), !1
}

function callTopupAPI(n) {
    var r = _0x3511a3,
        e = sessiontime,
        t = $(r(424))[r(385)](),
        o = getStorageValue(r(366));
    voucher = "0" == e ? "" == t && null == o ? (a = replaceAll(mac, ":"), $(r(424))[r(385)](a), a) : null != o ? getStorageValue("activeVoucher") : $(r(424))[r(385)]() : $("#nouptime")[r(385)]();
    var a = "";
    typeof uIp !== r(371) && "0" == e && (a = r(415) + uIp), extendTimeCriteria = r("" != t || null != o ? 328 : 240), $[r(252)]({
        type: r(219),
        url: "http://" + vendorIpAddress + r(380),
        data: r(414) + voucher + r(386) + mac + a + extendTimeCriteria,
        success: function(e) {
            var t, n, o = r;
            1 == EnableTelegram && (0 == VendoOption ? n = o(381) + mac + o(260) + dev_ip + o(377) + vendorIpAddress + "%0A--------------------------------------------" : 1 == VendoOption ? (t = $(o(230))[o(242)](), n = "--------------------------------------------%0A Insert Coin %0A--------------------------------------------%0A MAC: " + mac + o(260) + dev_ip + o(220) + t + o(377) + vendorIpAddress + o(244)) : 2 == VendoOption && (n = o(381) + mac + o(260) + dev_ip + o(349) + vendorName + o(377) + vendorIpAddress + o(244)), t = o(390) + telegramToken + o(305) + telechatId + o(401) + n + "&parse_mode=html", (n = new XMLHttpRequest)[o(319)](o(237), t, !0), n[o(365)]()), "true" == e[o(281)] ? ($(o(344))[o(369)](o(294)), voucher = e[o(243)], insertingCoin = !0, null == timer && (timer = setInterval(checkCoin, 1e3)), insertcoinbg[o(214)]()) : (notifyCoinSlotError(e[o(209)]), clearInterval(timer), timer = null)
        },
        error: function(e, t) {
            setTimeout(function() {
                n < 2 ? callTopupAPI(n + 1) : toastr.error("Coin slot is not available as of the moment, Please try again later")
            }, 1e3)
        }
    })
}

function checkCoin() {
    var r = _0x3511a3;
    $[r(252)]({
        type: r(219),
        url: "http://" + vendorIpAddress + r(284),
        data: r(414) + voucher,
        success: function(e) {
            var t, n, o = r;
            e.status == o(320) ? (totalCoinReceived = parseInt(e[o(387)]), $(o(411)).html(e.totalCoin), $("#totalTime")[o(298)](credits(parseInt(e[o(333)]))), toastr[o(261)](e.newCoin + o(372), "", {
                closeButton: !1
            }), coinCount.play(), 1 == EnableTelegram && CoinDropNotify && (n = "--------------------------------------------%0A Inserted Coin %0A--------------------------------------------%0A Amout: " + e[o(422)] + o(231) + mac + o(260) + dev_ip + "%0A--------------------------------------------", t = o(390) + telegramToken + o(305) + telechatId + o(401) + n + o(408), (n = new XMLHttpRequest).open(o(237), t, !0), n[o(365)]())) : e.errorCode == o(417) || ("coin.not.inserted" == e[o(209)] ? (t = parseInt(parseInt(e[o(270)]) / 1e3), n = parseFloat(e[o(402)]), n = parseInt(1e3 * t / n * 100), 0 < (totalCoinReceived = parseInt(e[o(387)])) && $(o(212)).text(o(384)), 0 == t ? ($(o(344)).modal(o(322)), insertcoinbg[o(307)](), (insertcoinbg[o(423)] = 0) < totalCoinReceived ? forceLogin() : toastr[o(331)](o(282))) : (totalCoinReceived = parseInt(e[o(387)]), $(o(411))[o(298)](e[o(387)]), $(o(309))[o(298)](e[o(396)]), $(o(364))[o(298)](secondsToDhms(parseInt(e[o(333)]))), $(o(263))[o(246)](o(301), o(400) + n + "%"), $(o(239))[o(298)](t))) : e[o(209)] == o(302) ? (insertcoinbg[o(307)](), insertcoinbg.currentTime = 0, clearInterval(timer), $(o(344))[o(369)](o(322)), 0 == totalCoinReceived ? toastr[o(331)](o(241)) : forceLogin()) : (notifyCoinSlotError(e.errorCode), clearInterval(timer)))
        },
        error: function(e, t) {
            console.log("error!!!")
        }
    })
}

function insertCoinhidden() {
    var e = _0x3511a3;
    clearInterval(timer), timer = null, insertingCoin = !1, insertcoinbg.pause(), (insertcoinbg[e(423)] = 0) == totalCoinReceived && $.ajax({
        type: "POST",
        url: e(379) + vendorIpAddress + e(416),
        data: "voucher=" + voucher + "&mac=" + mac,
        success: function(e) {},
        error: function(e, t) {}
    })
}

function convert() {
    var n = _0x3511a3,
        e = $(n(374))[n(385)]();
    "" != e ? (voucherToConvert = e, $[n(252)]({
        type: n(219),
        url: n(379) + vendorIpAddress + "/convertVoucher",
        data: "voucher=" + voucher + n(289) + voucherToConvert,
        success: function(e) {
            var t = n;
            "true" == e[t(281)] ? (toastr[t(248)](t(293)), null == timer && (timer = setInterval(checkVoucher, 1e3))) : (insertCoinhidden(), toastr.error(t(312))), voucherToConvert = ""
        },
        error: function() {
            var e = n;
            insertCoinhidden(), toastr[e(331)](e(312)), voucherToConvert = ""
        }
    })) : (insertCoinhidden(), toastr[n(331)](n(398)))
}

function voucherAction() {
    var e = _0x3511a3;
    vendorIpAddress = "100.67.101.254"; //VOUCHER MONKAYO
    if ("" != $(e(374)).val()) return callTopupAPIVoucher(totalCoinReceived = 0), !1;
    toastr[e(331)]("Please enter voucher code!")
}

function callTopupAPIVoucher(n) {
    var o = _0x3511a3,
        e = sessiontime,
        t = $(o(217))[o(385)](),
        r = getStorageValue(o(366));
    voucher = "0" == e ? "" == t && null == r ? (a = replaceAll(mac, ":"), $(o(217)).val(a), a) : null != r ? getStorageValue("activeVoucher") : $(o(217))[o(385)]() : $(o(264)).val();
    var a = "";
    typeof uIp !== o(371) && "0" == e && (a = "&ipAddress=" + uIp), extendTimeCriteria = o("" != t || null != r ? 328 : 240), $[o(252)]({
        type: o(219),
        url: o(379) + vendorIpAddress + o(380),
        data: o(414) + voucher + o(386) + mac + a + extendTimeCriteria,
        success: function(e) {
            var t = o;
            "true" == e.status ? (voucher = e[t(243)], insertingCoin = !0, convert()) : (notifyCoinSlotError(e[t(209)]), clearInterval(timer), timer = null)
        },
        error: function(e, t) {
            setTimeout(function() {
                var e = _0xd8f8;
                n < 2 ? callTopupAPI(n + 1) : toastr[e(331)](e(272))
            }, 1e3)
        }
    })
}

function checkVoucher() {
    var o = _0x3511a3;
    $[o(252)]({
        type: o(219),
        url: o(379) + vendorIpAddress + o(284),
        data: o(414) + voucher,
        success: function(e) {
            var t = o;
            e[t(281)] == t(320) ? (totalCoinReceived = parseInt(e[t(387)]), $(t(212))[t(413)]()) : "coinslot.busy" == e.errorCode ? (clearInterval(timer), insertCoinhidden(), 0 < totalCoinReceived && forceLogin()) : clearInterval(timer)
        },
        error: function(e, t) {
            var n = o;
            console[n(277)](n(273))
        }
    })
}

function secondsToDhms(e) {
    var t = _0x3511a3;
    e = Number(e);
    var n = Math[t(378)](e / 86400),
        o = Math[t(378)](e % 86400 / 3600),
        r = Math[t(378)](e % 3600 / 60),
        a = Math[t(378)](e % 60),
        e = 0 < n ? "<b>" + n + t(286) : "",
        a = 0 < a ? "<b>" + a + t(362) : t(271);
    if (0 < n && 0 == o) {
        var i = 0 < r ? t(280) + r + t(362) + "" : "<b>0</b>";
        return e + (0 < o ? t(280) + o + t(362) + "" : t(271)) + t(389) + i + "min." + a + t(250)
    }
    if (0 == n && 0 < o && 0 == r) {
        i = 0 < r ? t(280) + r + t(362) + "" : t(271);
        return e + (0 < o ? "<b>" + o + t(405) : "") + i + t(253) + a + t(250)
    }
    i = 0 < r ? t(280) + r + t(251) + "" : "";
    return e + (0 < o ? t(280) + o + t(405) + "" : "") + i + a + t(250)
}

function credits(e) {
    var t = _0x3511a3;
    e = Number(e);
    var n = Math[t(378)](e / 86400),
        o = Math[t(378)](e % 86400 / 3600),
        r = Math[t(378)](e % 3600 / 60),
        e = Math[t(378)](e % 60);
    return (0 < n ? n + t(1 == n ? 346 : 397) : "") + "" + (0 < o ? o + "" : "0") + "h:" + (0 < r ? r + "" : "0") + "m:" + (0 < e ? e + "" : "0") + "s"
}
null == voucher && (voucher = ""), "" != voucher && $(_0x3511a3(424))[_0x3511a3(385)](voucher), $(_0x3511a3(212))[_0x3511a3(413)](function(e) {
    var o = _0x3511a3;
    clearInterval(timer), timer = null, insertcoinbg[o(307)](), (insertcoinbg[o(423)] = 0) < totalCoinReceived && $[o(252)]({
        type: o(219),
        url: o(379) + vendorIpAddress + o(295),
        data: o(414) + voucher,
        beforeSend: function() {
            var e, t, n = o;
            1 == EnableTelegram && (0 == VendoOption ? t = n(335) + mac + n(351) + dev_ip + n(325) + totalCoinReceived + n(313) + voucher + n(377) + vendorIpAddress + n(419) : 1 == VendoOption ? (e = $(n(230))[n(242)](), t = "--------------------------------------------%0A Connecting %0A--------------------------------------------%0A MAC: " + mac + n(351) + dev_ip + n(220) + e + n(377) + vendorIpAddress + "%0A Total Coin Receive: " + totalCoinReceived + n(313) + voucher + "%0A--------------------------------------------") : 2 == VendoOption && (t = n(335) + mac + "%0A IP:" + dev_ip + n(220) + vendorName + n(377) + vendorIpAddress + n(325) + totalCoinReceived + n(313) + voucher + n(419)), e = n(390) + telegramToken + n(305) + telechatId + n(401) + t + "&parse_mode=html", (t = new XMLHttpRequest)[n(319)]("GET", e, !0), t[n(365)]())
        },
        success: function(e) {
            var t = o;
            totalCoinReceived = 0, e.status == t(320) ? forceLogin() : notifyCoinSlotError(e[t(209)])
        },
        error: function(e, t) {
            forceLogin()
        }
    })
}), $(_0x3511a3(223))[_0x3511a3(413)](function(e) {
    var d = _0x3511a3;
    $.ajax({
        type: d(237),
        url: "http://" + vendorIpAddress + d(352),
        crossOrigin: !0,
        contentType: d(345),
        success: function(e) {
            var s = d;
            $(s(227))[s(369)](s(294));
            var t = e[s(311)]("|"),
                n = "";
            for (r in t) {
                var o = t[r][s(311)]("#"),
                    a = 60 * parseInt(o[2]),
                    i = 60 * parseInt(o[3]);

                function c(e) {
                    var t = s,
                        n = Math.floor(e / 86400),
                        o = Math[t(378)](e % 86400 / 3600),
                        r = Math.floor(e % 3600 / 60),
                        a = 0 < n ? n + t(1 === n ? 358 : 278) : "",
                        i = 0 < o ? o + "" : "0",
                        e = 0 < r ? r + "" : "0";
                    return 0 < n && 0 == o && 0 == r ? a : 0 < r && 0 == o && 0 == n ? e + t(259) : 0 < o && 0 == r && 0 == n ? i + t(340) : a + i + "h:" + e + "m"
                }
                var u = c(a),
                    l = c(i);
                l == s(314) || 0 == i ? l = s(418) : a == i && (l = s(334)), n = (n = (n = (n += s(210)) + "<td>₱ " + o[1] + s(327)) + "<td>" + u + s(391)) + "<td>" + l + "</td>", n += "</tr>", $("#ratesBody")[s(298)](n)
            }
        },
        error: function(e, t) {
            setTimeout(function() {
                var e = _0xd8f8;
                toastr[e(331)](vendorName + e(236))
            }, 1e3)
        }
    })
}), jQuery(document)[_0x3511a3(323)](function(o) {
    var n, r, a, i;
    n = o("#vendoSelected"), a = n[(r = _0xd8f8)(385)](), i = n[r(246)]("id"), o(n).find(r(375))[r(341)](function() {
        var e, t = r;
        o(this)[t(385)]() && (e = o(t(393) + o(this)[t(385)]() + t(367) + i + t(337) + o(this)[t(242)]() + t(258)), o(this)[t(385)]() == a && e[t(321)](t(332)), e.insertBefore(n))
    }), n[r(322)](), o(document).on(r(413), r(330), function() {
        var e = r,
            t = o(this).data("target");
        o(e(306) + t + '"]')[e(221)](e(332)), o(this)[e(321)]("selected"), o(e(287))[e(369)](e(322));
        var n = "#" + t + e(290);
        o(n)[e(255)](e(332));
        t = "#" + t + ' option[value="' + o(this)[e(396)]("value") + '"]';
        o(t)[e(246)](e(332), "selected"), o(t).change()
    })
});